Simply extract the archive into your project's assets folder.
Once you start ReactiVision and assign the FiducialController script to a GameObject in Unity you can start playing around.

If you have any questions regarding Uniducial feel free to contact me at andre.groeschel@gmail.com

Have fun!