#!/bin/sh
javadoc -d doc -sourcepath src TUIO

